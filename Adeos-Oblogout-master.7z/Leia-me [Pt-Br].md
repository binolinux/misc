
## Adeos-oblogout

Um tema com estilo simples para o "oblogout", totalmente feito com Inkscape e Amor &lt;3

Para instalar o tema você irá precisa (obviamente) do "oblogout", dos arquivos .png (contidos na pasta do tema) e fuce por aí pra econtrar o aquivo "oblogout.conf" (etc/oblogout.conf).

## Instalação

1 - Vá em "etc/oblogout.conf" para editar o arquivo com seu editor de texto favorito (gedit, mousepad, ou qualquer coisa que você preferir).

2 - Modifique-o adicionando "adeos-cores" ou "adeos-branco" após "buttontheme =" (exemplo: "buttontheme = adeos-cores"). Escolha de acordo com seu gosto.

3 - Mova a pasta correspondente para "usr/share/themes". (Se você escolher a versão "adeos-branco"; mova a pasta "adeos-branco" e assim por diante)

4 - Pronto!

![My image](https://github.com/bruhensant/Adeos-Oblogout/blob/master/Adeos%20v2%20-%20Cover.png)

## Contatos e Agradecimentos!

Eu: https://t.me/bruhensant    
Thiago Silva: https://t.me/Bezzy    
Spiral Architect: https://t.me/Spiral_Architect
