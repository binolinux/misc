
## Adeos-oblogout

A simple style theme for "oblogout", totally made with Inkscape and Love <3

To install the theme you will need (of course) "oblogout", the .png files (contained in the theme folder) and go around to find the "oblogout.conf" file (etc/oblogout.conf).

## Instalation 

1 - Go to "etc/oblogout.conf" to edit the file with your favorite text editor (gedit, mousepad, or whatever you prefer).

2 - Modify it by adding "adeos-cores" or "adeos-branco" after "buttontheme =" (example: "buttontheme = adeos-cores"). Choose according to your taste. "adeos-branco" is the white one version.

3 - Move the corresponding folder to "usr/share/themes". (i.e: If you choose the "adeos-cores" version, move the "adeos-cores" folder.)

4 - Enjoy! :D 

![My image](https://github.com/bruhensant/Adeos-Oblogout/blob/master/Adeos%20v2%20-%20Cover.png)

## Contact and Thanks

Me: https://t.me/bruhensant
Thiago Silva: https://t.me/Bezzy    
Spiral Architect: https://t.me/Spiral_Architect
