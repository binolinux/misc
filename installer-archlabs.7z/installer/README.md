# ArchLabs Installer

#### Features
+ Support for LUKS and/or LVM.
+ Create multiple users.
+ Simple & easy to follow configuration.
+ Automatic partitioning for whole devices.
+ Translations for 10 different languages.
+ Built-in error detection and capturing.

#### Requirements
+ `rsync` used to unpack the squashfs root.
+ `dialog` for all user input/output.
+ `geany` and `vim` for editing files post install.
+ `gparted` and `parted` for auto and manual partition creation.
+ `wipe` for the secure wipe option.
+ standard \*NIX tools `awk` `sed` `grep` `uniq` `sort` `find` `ping` `mkfs` `lsblk`.
+ `arch-chroot` used to perform operation in the chroot.
+ `chpasswd` to set root and user passwords.

#### If a network connection is available, the following will be used
+ `pacman` used to update the system and install/remove packages.
+ `reflector` for sorting the mirrorlist.
