#!/bin/bash

# Mate tweaks
gsettings set org.mate.caja.desktop computer-icon-visible false ; gsettings set org.mate.caja.desktop home-icon-visible false ; gsettings set org.mate.caja.desktop network-icon-visible false ; gsettings set org.mate.caja.desktop trash-icon-visible false ; gsettings set org.mate.caja.desktop volumes-visible false ; gsettings set com.solus-project.brisk-menu label-visible false ; gsettings set com.solus-project.brisk-menu dark-theme true ; gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ show-dock-item false
exit
