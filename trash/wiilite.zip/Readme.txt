WhereIsIt? Lite 3.95
Copyright (c) 1997-2009 Robert Galle
All Rights Reserved
http://www.whereisit-soft.com


GENERAL NOTES
=============

"WhereIsIt? Lite" is a free catalog browser for files, created with
WhereIsIt? cataloguing program. The Lite version is a minimized version
without any capabilities to change catalog data while still retaining full
browsing support, including powerful searching and report generator with
print preview. WhereIsIt? Lite does not impose any limititations found in 
the shareware version, such as number of opened catalogs at once. If you
are a user of standard WhereIsIt? program, you can use the Lite version as
a companion program to your give-away catalogs, enabling your clients
browsing catalogs without having to order the full version of WhereIsIt?.
Note that Lite version is a browser only, and it does not contain any
functionality that would allow users to create or modify catalogs in any 
way.

"WhereIsIt? standard" is a shareware software, priced at $39.95 USD. This 
software has all the capabilities of the Lite version, plus many additional 
functions that allow you to create and maintain your own catalogs. The 
evaluation version and other information are available for download from 
program's homepage (http://www.whereisit-soft.com).


SYSTEM REQUIREMENTS
===================

- Any 32-bit version of MS Windows (Windows 95/98/ME, Windows NT 4.0, 
  Windows 2000, Windows XP, Windows 2003, or Windows Vista)
- 5 MB free hard disk space for program installation and catalogs.
- Mouse or other Windows-compatible pointing device strongly recommended.


PROGRAM HIGHLIGHTS
==================

Unicode Compliant Software
--------------------------
WhereIsIt supports Unicode encodings on all Unicode-capable Windows operating 
systems. Unicode allows you to represent and edit text in multiple languages 
and world writing systems side by side. WhereIsIt supports files with Unicode 
file names, allows Unicode in all user-editable data, and uses UTF-8 encoding 
for storing textual data in catalogs.

Suitable for beginners and advanced users
-----------------------------------------
Very adjustable program with many options for power users, as well as easy
to use with default settings and Quick-Setup Wizard for all those who don't
want to get their hands dirty.

Explorer-like interface
-----------------------
Easy to use, familiar Explorer-like user interface with adjustable toolbar,
columns to choose between, and extensive use of object menus (right mouse
click).

Manageable catalog files
------------------------
Logical organization of databases, based on one or more catalogs. Each
catalog can easily be transferred as a single file to another computer, a
friend, a public forum...  Small catalog-file size with optional compression,
with approximate usage of 1 MB for 40.000 files and folders (that's about 6
fully filed CD-ROMs). Internal database structure optimized for very efficient
access and small total size. Single-file, transferable catalog storage makes
sharing your data easy.

Fast access to item's properties
--------------------------------
Fast and easy access to every item's detailed properties, from wherever you
are. Want to get item's description? Just leave mouse pointer on it for a
moment, description will popup as a tool-tip!.

Built-in ASCII viewer and compressed file extracting
----------------------------------------------------
If you had the original media delivered together with WhereIsIt? Lite, you
can copy, view, or launch files directly from catalog, even if compressed
inside archive files! WhereIsIt? Lite supports many archive file formats,
including ZIP, ARJ, RAR, LHA/LZH, ARC, GZIP, self-extract, and more!

Manageable catalog files
------------------------
Logical organization of databases, based on one or more catalogs. Each
catalog can easily be transferred as a single file to another computer, a
friend, a public forum...  Small catalog-file size, with approximate usage
of 2 MB for 70.000 files and folders (that's about 10 fully filed CD-ROMs).
Internal database structure optimized for very efficient access and small
total size. Single-file, transferable catalog storage makes sharing your
data easy.

Powerful searching finds what you need
--------------------------------------
Powerful multi-threaded searching, with detailed settings on what to search
for, where to search and how to search. Use either Quick Search to quickly
find your items by name or description, or start up the Advanced Search with
Search Expression Editor, allowing you to write complex search queries using
full set of available search criteria and Boolean logic operators.
Searching for duplicate items is there, too, as well as analyzing how data
has changed since last cataloging, or checking if older or newer versions of
files are present somewhere in the catalog.

Report generator with print preview for summarizing your catalogs
-----------------------------------------------------------------
Adjustable and powerful report generator adds a final professional touch to
your catalog collection. Export your data to ASCII file, Excel table, rich-
text document, HTML document, print on your printer, or send by fax using
the Microsoft Fax, after previewing it on full-screen, with adjustable zoom.

... and many, many more!


DISTRIBUTION
============

"WhereIsIt? Lite" is a freeware program, and can be freely distributed as
you like, provided it is distributed in the original installation form.
Distributing ready-to-run executables is not recommended, see the install
notes in INSTALL.TXT for more details.


CONTACTING THE AUTHOR
=====================

Author's address: Robert Galle
                  Pavsiceva 36
                  1370 Logatec
                  Slovenia (Europe)
                  robert.galle@whereisit-soft.com

E-Mail:           support@whereisit-soft.com (for registered users only)

Main WWW Page:    http://www.whereisit-soft.com

Mirror Site:      http://www2.whereisit-soft.com

