# Xfwm Standalone Session
Just a helper for running Xfwm4 session without a full desktop environment. I include xfwm4.dekstop file to make xfwm4 session appears in your login manager. And a startup file in ~/.config/xfwm4 to make your life easier. Maybe this package is useless :D
