<p align="center">
  <img src="https://github.com/arch4life/artixlinux/raw/master/artixlinux.png" alt="Artix Linux Script">
</p>

# <p align="center">Artix Linux Script</p>
<br />
<b>1.</b> Dê boot no live do Artix e siga os passos abaixo:
<br />
<b><i>a) </b></i>Verifique sua conexão com o Github usando o comando abaixo
<br />
<i>ping -c3 github.com</i>
<br />
<b><i>b) </b></i>Caso esteja OK, digite os comandos abaixo
<br />
<i>loadkeys br-abnt</i><br />
<i>cfdisk</i><br />
<b><i>c) </b></i>Crie as partições no disco, exemplo:<br />
- 20GB para o <b>/</b><br />
- 2GB para o <b>swap</b>, caso queira usá-lo<br />
- restante do disco para o <b>/home</b><br />
<b><i>d)</i></b> Salve as alterações selecionando <b>Write</b> e depois <b>"yes"</b><br />

