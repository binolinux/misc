## Fedora

<b>Links:</b><br />
https://getfedora.org/pt_BR/workstation/download/<br />
https://getfedora.org/pt_BR/workstation/prerelease/<br />
https://apps.fedoraproject.org/packages/s/<br />
https://doc.fedora-fr.org/wiki/Netinstall_de_Fedora#Introduction<br />
https://apps.fedoraproject.org/packages/<br />
https://www.blogopcaolinux.com.br/2017/11/Guia-pos-instalacao-Fedora-27-Workstation.html

