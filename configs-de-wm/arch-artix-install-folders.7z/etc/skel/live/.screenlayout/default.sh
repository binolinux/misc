#!/bin/sh
xrandr --output VGA-1 --off --output DVI-D-1 --off --output HDMI-1 --mode 1920x1080 --pos 0x0 --rotate normal
