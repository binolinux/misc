sleep 10s
killall conky
cd "/opt/conky"

#Debian
conky -c "/opt/conky/Debian/debian" &
conky -c "/opt/conky/Atalhos-Font-Zekton" &

#Ubuntu
#conky -c "/opt/conky/Ubuntu/ubuntu" &
#conky -c "/opt/conky/Atalhos-Font-Zekton" &

# Fonte Zekton
#conky -c "/opt/conky/Atalhos-Font-Zekton" &
#cd "/opt/conky/Jesse_Time"
#conky -c "/opt/conky/Jesse_Time/Time-Font-Zekton" &

# Fonte Bauhaus
#conky -c "/opt/conky/Atalhos-Font-Bauhaus" &
#cd "/opt/conky/Jesse_Time"
#conky -c "/opt/conky/Jesse_Time/Time-Font-Bauhaus" &
