sleep 10s
killall conky
cd "/opt/conky"
conky -c "/opt/conky/Atalhos-Font-Zekton" &
cd "/opt/conky/Jesse_Time"
conky -c "/opt/conky/Jesse_Time/Time-Font-Zekton" &
