#!/usr/bin/env bash

# Terminate already running bar instances
killall -q polybar

# Wait until the processes have been shut down
while pgrep -u $UID -x polybar >/dev/null; do sleep 0.7; done

# Launch
polybar main -r -c $HOME/.config/polybar/config-xfwm4.ini &
