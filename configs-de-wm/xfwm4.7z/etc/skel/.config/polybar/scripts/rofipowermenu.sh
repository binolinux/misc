#!/bin/sh
# rofi power menu
# Franklin Souza
# @FranklinTech

# cores do pywal
. "${HOME}/.config/wal/colors.sh"

#chosen=$(echo -e " Sair \n鈴 Suspender\n漏 Reiniciar\n襤 Desligar\n Bloquear Tela" | rofi -theme gruvbox-dark-hard -p   -dmenu -i -lines 5)
chosen=$(echo -e " Bloquear tela \n Encerrar\n Reiniciar\n Desligar" | rofi -dmenu -i -lines 4 -hide-scrollbar -width 30 -color-window "$color0, $color0, $color0" -color-normal "$color0, $color7, $color0, $color7, $color0" -color-active "$color0, $color7, $color0, $color7, $color0" -color-urgent "$color0, $color7, $color0, $color7, $color0" -font "Bahamas Regular 15")
elif [[ $chosen == *"Bloquear tela"* ]];then
    sleep 1s && lock
if [[ $chosen == *"Encerrar"* ]]; then
    #i3-msg exit
    pkill -9 -u $USER
#elif [[ $chosen == *"Suspender"* ]]; then
#    systemctl suspend
elif [[ $chosen == *"Reiniciar"* ]]; then
    #systemctl reboot
    dbus-send --system --print-reply --dest=org.freedesktop.login1 /org/freedesktop/login1 "org.freedesktop.login1.Manager.Reboot" boolean:true
elif [[ $chosen == *"Desligar"* ]]; then
    #systemctl poweroff
    dbus-send --system --print-reply --dest=org.freedesktop.login1 /org/freedesktop/login1 "org.freedesktop.login1.Manager.PowerOff" boolean:true
fi
