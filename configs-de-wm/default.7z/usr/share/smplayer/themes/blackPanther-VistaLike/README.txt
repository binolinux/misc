Icon set created by Charles Barcza [kbarcza@blackpanther.hu] for SMPlayer blackPanther OS version
Name: blackPanther-VistaLike
License: GPL