------------------------ SMPLAYER THEME PAPIRUS DARK ------------------------
AUTHOR:
Alexey Varfolomeev 
https://github.com/PapirusDevelopmentTeam
