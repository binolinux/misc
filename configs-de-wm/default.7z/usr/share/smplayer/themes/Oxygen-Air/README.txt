Icons taken from KDE 4.3.2
License: GPLv3



Icon theme created for SMPlayer by Redxii <redxii@users.sourceforge.net>

Uses some 
of the original Oxygen icons (dual license: Creative Common 
Attribution-ShareAlike 3.0 License or the GNU Library General Public License).
