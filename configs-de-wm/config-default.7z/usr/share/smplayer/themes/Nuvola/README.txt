Icons taken from http://www.kde-look.org/content/show.php?content=5358
License: LGPL

Icon theme created for SMPlayer by Nardog <nardog@e2umail.com>
