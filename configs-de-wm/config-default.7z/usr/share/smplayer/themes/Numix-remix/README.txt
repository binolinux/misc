Numix icon theme for SMPlayer

Icons taken from The Numix Project <http://www.numixproject.org>
License: GNU General Public License and GNU Lesser General Public License



