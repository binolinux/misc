====================
Noia Icons Theme
====================

Noia Icons for SMPlayer based on the Noia Icons for KDE.

Feel free to change/update/modify this icons theme.

Mixed by Vitaliy Motsyo <vitalikmotsyo@gmail.com>

Icons taken from http://www.carlitus.net License:  LGPL.
