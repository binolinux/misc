Theme created by Ricardo Villalba.

This theme is based on Breeze-dark by NitruxSA, but with larger icons
and a Qt stylesheet.

Icons from:
https://github.com/Ken-Vermette/plasma-next-icons
License: LGPLv3

Original stylesheet from:
https://github.com/ColinDuquesnoy/QDarkStyleSheet
License: MIT. Images: CC-BY.
https://github.com/ColinDuquesnoy/QDarkStyleSheet/blob/master/LICENSE.md
