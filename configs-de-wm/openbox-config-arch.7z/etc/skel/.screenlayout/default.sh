#!/bin/sh
xrandr --output VGA-1 --primary --mode 1920x1080 --pos 0x0 --rotate normal --output DVI-D-1 --off
