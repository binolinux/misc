industrial-arch
===============

Arch linux theme based in a Industrial Theme for LXDM