The go plugin is deprecated. Use the [golang plugin](https://github.com/ohmyzsh/ohmyzsh/tree/master/plugins/golang) instead.
