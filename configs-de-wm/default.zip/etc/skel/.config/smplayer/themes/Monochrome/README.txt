Theme created by goetzc.

Icons taken from KFaenza (GPL,
http://kde-look.org/content/show.php/KFaenza?content=143890),
Leo-like-icons (GPL,
http://kde-look.org/content/show.php/?content=124176) and Elementary
(GPL, https://launchpad.net/elementaryicons).

From:
http://smplayer.sourceforge.net/forum/viewtopic.php?f=7&t=5592
