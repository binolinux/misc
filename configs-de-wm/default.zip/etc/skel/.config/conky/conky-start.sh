#!/bin/bash

killall conky
sleep 5s
cd "$HOME/.config/conky"
conky -d -c "$HOME/.config/conky/datetime-current" &


