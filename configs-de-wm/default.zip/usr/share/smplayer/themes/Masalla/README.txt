Theme created by Ricardo Villalba <rvm@users.sourceforge.net> using
the Masalla icons:
http://hayderctee.deviantart.com/art/Masalla-Icon-Themes-540865415

License: GPL-3.0+
