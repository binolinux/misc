Gnome icon theme for SMPlayer
Feel free to send me comments or suggestions <31337h4ck3r@gmail.com>

Icons taken from The GNOME Project <http://www.gnome.org>
License: GNU General Public License and GNU Lesser General Public License