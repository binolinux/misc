Icons taken from http://www.gnome-look.org/content/show.php/Oxygen+Refit+%5BIcons%5D?content=64589
License: LGPL

Icon theme created for SMPlayer by Ricardo Villalba <rvm@users.sourceforge.net>
