====================
Gartoon Icons Theme
====================

Gartoon Icons for SMPlayer based on the Gartoon Icons for Gnome.

Feel free to change/update/modify this icons theme.

Mixed by Kud Gray <kud.gray@gmail.com>

Icons taken from http://art.gnome.org/themes/icon/1001. License: GPL.
