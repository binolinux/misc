#!/bin/bash
sleep 0.2
xkill

