#
# Aliases
# (sorted alphabetically)
#

alias https='http --default-scheme=https'

