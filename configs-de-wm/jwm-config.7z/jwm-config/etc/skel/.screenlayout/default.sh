#!/bin/sh
xrandr --output VGA-0 --off --output HDMI-0 --primary --mode 1024x768 --pos 0x0 --rotate normal
