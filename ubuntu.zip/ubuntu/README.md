<p align="center"><img src="https://github.com/binolinux/ubuntu/raw/master/ubuntu-logo.png" alt="Ubuntu Bionic Script"></p>

# <p align="center">Bionic Beaver Script</p><br/>
- Abra o terminal, copie e cole as linhas abaixo:</br>
<i>sudo su</i><br/>
<i>apt install --no-install-recommends debootstrap arch-install-scripts git ca-certificates</i><br/>
- Monte a unidade destino em formatada em ext4, btrfs ou xfs em /mnt. Exemplo abaixo:</br>
<i>mount /dev/sda1 /mnt</i></br>
- Baixe os arquivos de instalação do git abaixo:</br>
<i>git clone --depth 1 https://github.com/binolinux/ubuntu /mnt/ubuntu</i></br>
- Inicie a instalação</br>
<i>sh /mnt/ubuntu/pre-setup</i></br>
