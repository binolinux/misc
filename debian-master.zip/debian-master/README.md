<p align="center">
  <img src="https://github.com/arch4life/debian/raw/master/debian-logo.png" alt="Cinnamon / Mate / XFCE Script">
</p>

# <p align="center">Cinnamon / Mate / XFCE Script</p>
<br />
Acesse o sistema como usuário <b><i>root</b></i>.
<br />
<b><i>a) </b></i>Digite os comandos abaixo<br />
<i>apt install --no-install-recommends -y git ca-certificates dhcpcd5 p7zip-full</i><br />
<i>systemctl enable dhcpcd ; systemctl start dhcpcd</i>
<br /><i>ping -c3 github.com</i><br />
<b><i>b) </b></i>Caso esteja pingando no Github, digite os comandos abaixo:<br />
<i>git clone https://github.com/arch4life/debian</i><br />
<i>sh ./debian/install</i><br />
<b><i>c) </b>Se não pingar no Github, reinicie a máquina e repita no processo:
<br /><i>ping -c3 github.com</i><br />
<i>git clone https://github.com/arch4life/debian</i><br />
<i>sh ./debian/install</i>

