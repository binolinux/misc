<p align="center">
  <img src="https://github.com/arch4life/ubuntu/raw/master/ubuntu-logo.png" alt="Cinnamon Minimal">
</p>

# <p align="center">Cinnamon Minimal</p>
<br />
<b>1.</b> Acesse o sistema como usuário <b><i>normal</b></i>.
<br />
<b><i>a) </b></i>Verifique sua conexão com o Github usando o comando abaixo
<br />
<i>ping -c3 github.com</i>
<br />
<b><i>b) </b></i>Caso esteja OK, digite os comandos abaixo
<br />
<i>apt install --no-install-recommends -y git ca-certificates</i>
<br />
<i>git clone https://github.com/arch4life/ubuntu</i>
<br />
<i>sh ./ubuntu/cinnabuntu</i>

