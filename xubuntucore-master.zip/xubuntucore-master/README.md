<p align="center">
  <img src="https://github.com/arch4life/obuntu/blob/master/ubuntu-logo.png" alt="Xubuntu Spiral">
</p>

# <p align="center">XFCE</p>
<br />
Acesse o sistema como usuário <b><i>comum</b></i>.
<br />
<b><i>a) </b></i>Digite os comandos abaixo:<br />
<i>sudo apt install --no-install-recommends -y git ca-certificates dhcpcd5</i><br />
<i>sudo systemctl enable dhcpcd ; sudo systemctl start dhcpcd</i>
<br /><i>ping -c3 github.com</i><br />
<b><i>b) </b></i>Caso esteja pingando no Github, digite os comandos abaixo:<br />
<i>git clone https://github.com/arch4life/xubuntucore</i><br />
<i>sh ./xubuntucore/install</i><br />
<b><i>c) </b>Se não pingar no Github, reinicie a máquina e repita no processo:
<br /><i>ping -c3 github.com</i><br />
<i>git clone https://github.com/arch4life/xubuntucore</i><br />
<i>sh ./xubuntucore/install</i><br />
