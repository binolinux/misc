#!/bin/bash

#Carregador do Conky
sleep 25s
killall conky
cd "/opt/conky"

# Arch Linux
conky -c  "/opt/conky/Arch/arch" &
#conky -c  "/opt/conky/Atalhos-Font-Zekton" &

# Deixe apenas "1" das opções abaixo descomentada (sem o '#')
#conky -c "/opt/conky/conky-grey.conf" &
#conky -c "/opt/conky/conky-green.conf" &
#conky -c "/opt/conky/conky-orange.conf" &
#conky -c "/opt/conky/conky-black.conf" &

# OU use a combinação abaixo
#conky -c "/opt/conky/Atalhos-Font-Zekton" &
#conky -c "/opt/conky/Jesse_Time/Time-Font-Zekton" &

# OU use a opção abaixo para Debian
#conky -c  "/opt/conky/Debian/debian"
